f3:-
    display('Introduce A: '),
    read(A),
    display('Introduce B: '),
    read(B),
    display('Introduce C: '),
    read(C),
    display('Introduce E: '),
    read(E),
    Y is ((A+3*E-7*C^2*B)*4)/(5*(B-C)^2),
    display('El valor de Y es: '),
    display(Y).

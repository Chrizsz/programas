g4:-
    display('Introduce A: '),
    read(A),
    display('Introduce B: '),
    read(B),
    display('Introduce C: '),
    read(C),
    Y is (5*C+B^3-(A+8)/5)/(C+4*A+A/(2*B)),
    display('El valor de Y es: '),
    display(Y).

ejerdos:-
	display('Ingresa el valor A: '),
	read(A),
	display('Ingresa el valor B: '),
	read(B),
	display('Ingresa el valor C: '),
	read(C),
	display('Ingresa el valor D: '),
	read(D),
	display('Ingresa el valor E: '),
	read(E),
	display('Ingresa el valor F: '),
	read(F),

	Y is B*(A+C*F/D)^3+E,
	display('El valor de Y es: '),
	display(Y).

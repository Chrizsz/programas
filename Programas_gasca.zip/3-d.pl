cuarto:-display('Dame A:'),
	read(A),
	display('Dame B:'),
	read(B),
        display('Dame C:'),
	read(C),
	Y is 5*C+3*B^2-(A+B/C)^7,
	display('El resultado de Y='),
	display(Y).

f4:-
    display('Introduce A: '),
    read(A),
    display('Introduce B: '),
    read(B),
    display('Introduce C: '),
    read(C),
    display('Introduce D: '),
    read(D),
    Y is (B+8*A)/((C^5-1)/D)+(2*C)/(B+D),
    display('El valor de Y es: '),
    display(Y).

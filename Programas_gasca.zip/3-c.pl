tercero:-display('Dame A:'),
	read(A),
	display('Dame B:'),
	read(B),
        display('Dame C:'),
	read(C),
	Y is (4+8*B)*((3*A)/4-9*C),
	display('El resultado de Y='),
	display(Y).

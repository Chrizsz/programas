d4:-
    display('Introduce A: '),
    read(A),
    display('Introduce B: '),
    read(B),
    display('Introduce C: '),
    read(C),
    display('Introduce D: '),
    read(D),
    Y is ((7*D+4)/(3*A*B))/6-(A^3+D*C)/(B+4),
    display('El valor de Y es: '),
    display(Y).

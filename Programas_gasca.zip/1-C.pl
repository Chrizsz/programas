ejertres:-display('Ingresa el valor de A: '),
	  read(A),
	  display('Ingresa el valor de B: '),
	  read(B),
          display('Ingresa el valor de C: '),
	  read(C),
	  Y is (-A*B^3)+(2*C)-9,

          display('El valor de Y es: '),
	  display(Y).


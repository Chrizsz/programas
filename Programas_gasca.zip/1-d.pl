ejercuatro:-display('Ingrese el valor de A: '),
	read(A),
	display('Ingrese el valor de B: '),
	read(B),
	display('Ingrese el valor de C: '),
	read(C),
	display('Ingrese el valor de E: '),
	read(E),



	Y is (2*A-B^3/7)/(5*E+3)*C+(5*B+8*C^4),
	display('El valor de Y: '),
	display(Y).

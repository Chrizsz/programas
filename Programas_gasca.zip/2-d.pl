secciond:-display('Introducir A'),
	read(A),
	display('Introducir B'),
	read(B),
	display('Introducir C'),
	read(C),
        display('Introducir D'),
        read(D),

        Y is (D+5*A)*(D+1.5*(A+7*B)/(-3*C+D)/(B^2)),

	display('El resultado es:'),
	display(Y),
	display('\n').
